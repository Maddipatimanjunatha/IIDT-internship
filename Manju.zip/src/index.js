import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';


import BookSearch from './BookSearch';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BookSearch />
  </React.StrictMode>
);


