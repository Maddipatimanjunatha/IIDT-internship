import React from 'react';

const ProductList = ({ products }) => {
  return (
    <div className="product-list">
      {products.map(product => (
        <div key={product.id} className="product-item">
          <img src={product.image} alt={product.title} />
          <div className="product-details">
            <h4>{product.title}</h4>
            <b><p>{product.price}</p></b>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ProductList;
